tstem函数是对stem函数的一个高级封装，方便多次调用
part1-3分别对应这次实验3个实验
test是我测试的

！！！！！！！！特别提醒！！！！！！！！

在抄的时候记得改一下参数的名字，特别是y_coefficient和x_coefficient,建议改成B和A！


tstem函数如果不会用，可以用stem，part_3中有stem是怎么用的

