xn= [ones(1,32)];
hn= [0.2 0.2 0.2 0.2 0.2];
yn=conv(hn , xn);
n=0:length(yn)-1;
subplot(2,2,1);
stem (n, yn,'.');
title( ' (a)y(n)����'); 
xlabel ( 'n ' ); 
ylabel ( 'y(n) ');
